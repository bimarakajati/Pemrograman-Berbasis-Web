<?php
  $fname=$_GET["fname"];
  $lname=$_GET["lname"];
  echo "hello $fname $lname "
?>